#!/usr/bin/env python3
"""
Sync Content Generation Jobs with Replicate - Lambda Function

This Lambda function can be called via API to sync all content generation jobs
with their current status on Replicate, including error messages.
"""

import json
import boto3
import os
import urllib3
from datetime import datetime, timezone
from decimal import Decimal

# Initialize clients
dynamodb = boto3.resource('dynamodb')
secrets_client = boto3.client('secretsmanager')
http = urllib3.PoolManager()

# Configuration
CONTENT_JOBS_TABLE_NAME = os.environ.get('CONTENT_JOBS_TABLE_NAME', 'ai-influencer-content-jobs')
REPLICATE_API_TOKEN_SECRET = os.environ.get('REPLICATE_API_TOKEN_SECRET', 'replicate-api-token')

def get_secret(secret_name):
    """Retrieve secret from AWS Secrets Manager"""
    try:
        response = secrets_client.get_secret_value(SecretId=secret_name)
        return response['SecretString']
    except Exception as e:
        print(f"Error retrieving secret {secret_name}: {str(e)}")
        return None

def decimal_default(obj):
    """JSON serializer for DynamoDB Decimal types"""
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

def get_replicate_predictions(api_token, limit=50):
    """Get recent predictions from Replicate"""
    try:
        headers = {'Authorization': f'Token {api_token}'}
        
        response = http.request(
            'GET',
            f'https://api.replicate.com/v1/predictions?limit={limit}',
            headers=headers
        )
        
        if response.status == 200:
            data = json.loads(response.data.decode('utf-8'))
            return data.get('results', [])
        else:
            print(f"Failed to get predictions: HTTP {response.status}")
            return []
            
    except Exception as e:
        print(f"Error getting predictions: {str(e)}")
        return []

def get_replicate_prediction_status(prediction_id, api_token):
    """Get the current status of a specific prediction from Replicate"""
    try:
        headers = {'Authorization': f'Token {api_token}'}
        
        response = http.request(
            'GET',
            f'https://api.replicate.com/v1/predictions/{prediction_id}',
            headers=headers
        )
        
        if response.status == 200:
            return json.loads(response.data.decode('utf-8'))
        else:
            print(f"Failed to get prediction status for {prediction_id}: HTTP {response.status}")
            return None
            
    except Exception as e:
        print(f"Error getting prediction status for {prediction_id}: {str(e)}")
        return None

def update_job_with_replicate_data(job, prediction_data):
    """Update a job record with data from Replicate using unified schema"""
    try:
        content_jobs_table = dynamodb.Table(CONTENT_JOBS_TABLE_NAME)
        
        status = prediction_data.get('status')
        updates = {
            'replicate_status': status,
            'updated_at': datetime.now(timezone.utc).isoformat(),
            'replicate_prediction_id': prediction_data.get('id')
        }
        
        # Store raw Replicate data for debugging
        if prediction_data.get('input'):
            updates['replicate_input'] = prediction_data['input']
        if prediction_data.get('model'):
            updates['replicate_model'] = prediction_data['model']
        
        if status == 'succeeded':
            output = prediction_data.get('output')
            result_url = None
            
            # Handle different output formats
            if isinstance(output, list) and len(output) > 0:
                result_url = output[0]
            elif isinstance(output, str):
                result_url = output
            
            if result_url:
                # Determine result type based on URL or job type
                result_type = 'video' if any(ext in result_url.lower() for ext in ['.mp4', '.mov', '.webm']) else 'image'
                
                updates.update({
                    'status': 'completed',
                    'result_url': result_url,  # Unified field
                    'result_type': result_type,
                    'completed_at': datetime.now(timezone.utc).isoformat(),
                    'replicate_output': output  # Store raw output
                })
            
        elif status == 'failed':
            error_message = prediction_data.get('error', 'Job failed on Replicate')
            
            # Create structured error information
            error_details = {
                'category': 'replicate_error',
                'component': 'replicate',
                'original_error': error_message,
                'prediction_id': prediction_data.get('id')
            }
            
            # Add model-specific error categorization
            if 'LoRA' in error_message or 'lora' in error_message.lower():
                error_details['component'] = 'lora'
                error_details['category'] = 'model_error'
            elif 'kling' in error_message.lower():
                error_details['component'] = 'kling'
                error_details['category'] = 'model_error'
            
            updates.update({
                'status': 'failed',
                'error_message': error_message,  # Human readable
                'error_details': error_details,  # Structured data
                'replicate_output': prediction_data.get('error')  # Store raw error
            })
        
        elif status in ['starting', 'processing']:
            updates['status'] = 'processing'
        
        # Build update expression
        update_expression_parts = []
        expression_attribute_values = {}
        
        for key, value in updates.items():
            if value is not None:
                update_expression_parts.append(f"{key} = :{key}")
                expression_attribute_values[f":{key}"] = value
        
        if update_expression_parts:
            content_jobs_table.update_item(
                Key={'job_id': job['job_id']},
                UpdateExpression="SET " + ", ".join(update_expression_parts),
                ExpressionAttributeValues=expression_attribute_values
            )
            
        return True
        
    except Exception as e:
        print(f"Error updating job {job.get('job_id')}: {str(e)}")
        return False

def match_jobs_with_predictions(jobs, predictions):
    """Match jobs with Replicate predictions based on prompts and timing"""
    matches = []
    
    # Create a lookup of predictions by model and prompt
    prediction_lookup = {}
    for pred in predictions:
        # Extract prompt and model info
        input_data = pred.get('input', {})
        prompt = input_data.get('prompt', '')
        model = pred.get('model', '')
        created_at = pred.get('created_at', '')
        
        # Create a key for matching
        key = f"{prompt[:50]}_{model}"  # Use first 50 chars of prompt + model
        
        if key not in prediction_lookup:
            prediction_lookup[key] = []
        prediction_lookup[key].append(pred)
    
    # Try to match jobs with predictions
    for job in jobs:
        job_prompt = job.get('prompt', '')
        job_created = job.get('created_at', '')
        
        # If job already has a prediction ID, try to find exact match
        if job.get('replicate_prediction_id'):
            for pred in predictions:
                if pred.get('id') == job.get('replicate_prediction_id'):
                    matches.append((job, pred))
                    break
            continue
        
        # Try to match based on prompt and timing
        # Look for predictions with similar prompts
        for key, pred_list in prediction_lookup.items():
            if job_prompt[:50] in key or any(job_prompt.lower() in pred.get('input', {}).get('prompt', '').lower() for pred in pred_list):
                # Find the prediction closest in time to the job creation
                best_match = None
                min_time_diff = float('inf')
                
                try:
                    job_time = datetime.fromisoformat(job_created.replace('Z', '+00:00'))
                    
                    for pred in pred_list:
                        pred_time = datetime.fromisoformat(pred.get('created_at', '').replace('Z', '+00:00'))
                        time_diff = abs((job_time - pred_time).total_seconds())
                        
                        if time_diff < min_time_diff and time_diff < 3600:  # Within 1 hour
                            min_time_diff = time_diff
                            best_match = pred
                    
                    if best_match:
                        matches.append((job, best_match))
                        break
                        
                except Exception as e:
                    print(f"Error matching job timing: {str(e)}")
                    continue
    
    return matches

def lambda_handler(event, context):
    """Main Lambda handler for syncing jobs with Replicate"""
    
    try:
        print("Starting Replicate job sync via API...")
        
        # Parse request
        http_method = event.get('httpMethod', 'POST')
        
        # Handle CORS preflight
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS'
                },
                'body': ''
            }
        
        if http_method != 'POST':
            return {
                'statusCode': 405,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Method not allowed'})
            }
        
        # Get API token
        api_token = get_secret(REPLICATE_API_TOKEN_SECRET)
        if not api_token:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Could not retrieve Replicate API token'})
            }
        
        # Get all jobs from database
        content_jobs_table = dynamodb.Table(CONTENT_JOBS_TABLE_NAME)
        response = content_jobs_table.scan()
        jobs = response.get('Items', [])
        
        print(f"Found {len(jobs)} jobs in database")
        
        # Get recent predictions from Replicate
        predictions = get_replicate_predictions(api_token, limit=100)
        print(f"Found {len(predictions)} recent predictions on Replicate")
        
        # Match jobs with predictions and update
        matches = match_jobs_with_predictions(jobs, predictions)
        print(f"Found {len(matches)} job-prediction matches")
        
        updated_count = 0
        sync_results = []
        
        for job, prediction in matches:
            job_id = job.get('job_id', 'unknown')
            pred_id = prediction.get('id', 'unknown')
            old_status = job.get('status', 'unknown')
            new_status = prediction.get('status', 'unknown')
            
            print(f"Syncing job {job_id} with prediction {pred_id}")
            print(f"  Status: {old_status} -> {new_status}")
            
            if update_job_with_replicate_data(job, prediction):
                updated_count += 1
                
                result = {
                    'job_id': job_id,
                    'prediction_id': pred_id,
                    'old_status': old_status,
                    'new_status': new_status,
                    'updated': True
                }
                
                # Include error message if failed
                if new_status == 'failed':
                    error_msg = prediction.get('error', 'Unknown error')
                    result['error'] = error_msg
                    print(f"  Error: {error_msg}")
                
                sync_results.append(result)
            else:
                sync_results.append({
                    'job_id': job_id,
                    'prediction_id': pred_id,
                    'old_status': old_status,
                    'new_status': new_status,
                    'updated': False,
                    'error': 'Failed to update job'
                })
        
        # Also check for jobs with stored prediction IDs that weren't in recent predictions
        jobs_with_pred_ids = [job for job in jobs if job.get('replicate_prediction_id') and 
                             job.get('replicate_prediction_id') not in [p.get('id') for p in predictions]]
        
        for job in jobs_with_pred_ids:
            pred_id = job.get('replicate_prediction_id')
            prediction_data = get_replicate_prediction_status(pred_id, api_token)
            
            if prediction_data:
                job_id = job.get('job_id', 'unknown')
                old_status = job.get('status', 'unknown')
                new_status = prediction_data.get('status', 'unknown')
                
                print(f"Syncing job {job_id} with stored prediction {pred_id}")
                print(f"  Status: {old_status} -> {new_status}")
                
                if old_status != new_status:
                    if update_job_with_replicate_data(job, prediction_data):
                        updated_count += 1
                        
                        result = {
                            'job_id': job_id,
                            'prediction_id': pred_id,
                            'old_status': old_status,
                            'new_status': new_status,
                            'updated': True
                        }
                        
                        if new_status == 'failed':
                            error_msg = prediction_data.get('error', 'Unknown error')
                            result['error'] = error_msg
                            print(f"  Error: {error_msg}")
                        
                        sync_results.append(result)
        
        print(f"Sync complete: {updated_count} jobs updated")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Sync completed successfully',
                'jobs_processed': len(jobs),
                'predictions_checked': len(predictions),
                'jobs_updated': updated_count,
                'sync_results': sync_results
            }, default=decimal_default)
        }
        
    except Exception as e:
        print(f"Error during sync: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Sync failed: {str(e)}'})
        }
